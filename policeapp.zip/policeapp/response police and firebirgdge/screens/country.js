import React from 'react';
import {View, Text, TouchableOpacity,Button} from 'react-native';
import styles from '../styling';

function Country({navigation}) {
 
  return (
    <>
      <View>
        <Text>city firebirget provider !</Text>
        <Text>if you selected firebrigade then you need to identify your emergency level from the given level below !</Text>
        <Button
 
  title="Fire"
  color="orange"
  accessibilityLabel="Learn more about this purple button"
/>
<Button
 
  title="clinder blast"
  color="orange"
  accessibilityLabel="Learn more about this purple button"
/>
<Button
 
  title="short cirkit"
  color="orange"
  accessibilityLabel="Learn more about this purple button"
/>

      </View>
       
    </>
  );
}

export default Country;

